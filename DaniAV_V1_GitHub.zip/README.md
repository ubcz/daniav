DaniAV V1

DaniAV is a lightweight Windows security monitoring project with process, file, startup, network, logging, Windows Defender integration, and Discord Rich Presence support.

Repository

https://github.com/ubcz/daniav

Automatic requirements

If Python is installed, DaniAV_V1.bat automatically:

Detects the Python launcher or python command
Checks whether pip is available
Attempts to enable pip when necessary
Installs or updates every package in requirements.txt
Starts DaniAV after the requirements are ready

You do not need to manually run pip for a normal launch.

Running

Double click DaniAV_V1.bat.

You can also run:

python DaniAV_V1.py

The Python program also installs a missing dependency automatically when started directly.

Discord Rich Presence

Create a Discord application and copy its Application ID.

Set the environment variable:

DANIAV_DISCORD_CLIENT_ID

Optional:

DANIAV_GITHUB_URL

The default GitHub URL is:

https://github.com/ubcz/daniav

PowerShell example:

$env:DANIAV_DISCORD_CLIENT_ID="YOUR_APPLICATION_ID"
python DaniAV_V1.py --watch

Keep the Discord desktop client running while DaniAV is active.

Command line

python DaniAV_V1.py --once

Runs one scan.

python DaniAV_V1.py --watch

Runs continuous protection.

python DaniAV_V1.py --watch --no-rpc

Runs continuous protection without Discord Rich Presence.

python DaniAV_V1.py --watch --no-startup

Runs continuous protection without changing Windows startup registration.

Environment

DANIAV_SCAN_DELAY controls the continuous scan interval.

DANIAV_RPC_INTERVAL controls the minimum Discord activity update interval.

Safety

DaniAV is a lightweight monitoring tool and is not a replacement for Windows Defender or a commercial antivirus engine.

Detections are indicators that should be reviewed.

DaniAV does not automatically kill detected processes or delete suspicious files.

License

MIT

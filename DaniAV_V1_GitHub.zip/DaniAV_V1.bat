@echo off
setlocal EnableExtensions

cd /d "%~dp0"

echo.
echo ========================================
echo DaniAV V1
echo ========================================
echo.

set "PYTHON_CMD="

where py >nul 2>&1
if %errorlevel%==0 set "PYTHON_CMD=py"

if not defined PYTHON_CMD (
    where python >nul 2>&1
    if %errorlevel%==0 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD (
    echo Python was not found.
    echo.
    echo Install Python 3.9 or newer and make sure the Python
    echo launcher or python command is available.
    echo.
    pause
    exit /b 1
)

echo Python detected.
echo Installing DaniAV requirements automatically...
echo.

if not exist "requirements.txt" (
    echo requirements.txt was not found.
    echo.
    pause
    exit /b 1
)

%PYTHON_CMD% -m pip --version >nul 2>&1
if %errorlevel% neq 0 (
    echo pip was not found. Attempting to enable pip...
    %PYTHON_CMD% -m ensurepip --upgrade

    if %errorlevel% neq 0 (
        echo.
        echo Could not enable pip.
        echo Please repair your Python installation.
        echo.
        pause
        exit /b 1
    )
)

%PYTHON_CMD% -m pip install --disable-pip-version-check --upgrade -r "requirements.txt"

if %errorlevel% neq 0 (
    echo.
    echo The first dependency installation attempt failed.
    echo Retrying with pip repair...
    echo.

    %PYTHON_CMD% -m ensurepip --upgrade >nul 2>&1
    %PYTHON_CMD% -m pip install --disable-pip-version-check --upgrade -r "requirements.txt"

    if %errorlevel% neq 0 (
        echo.
        echo Requirements could not be installed.
        echo Check your internet connection and Python installation.
        echo.
        pause
        exit /b 1
    )
)

echo.
echo Requirements installed successfully.
echo Starting DaniAV...
echo.

%PYTHON_CMD% "DaniAV_V1.py"

set "EXIT_CODE=%errorlevel%"

echo.
if "%EXIT_CODE%"=="0" (
    echo DaniAV closed normally.
) else (
    echo DaniAV exited with code %EXIT_CODE%.
)

pause
exit /b %EXIT_CODE%

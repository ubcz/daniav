import argparse
import ctypes
import datetime
import hashlib
import logging
import os
import shutil
import subprocess
import sys
import time
import traceback
import winreg
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

APP_NAME = "DaniAV"
VERSION = "1.0.0"
DEFAULT_SCAN_DELAY = 30
DEFAULT_RPC_INTERVAL = 15
DEFAULT_GITHUB_URL = "https://github.com/ubcz/daniav"

USER_HOME = Path(os.environ.get("USERPROFILE", Path.home()))
DATA_DIR = USER_HOME / "AppData" / "Local" / APP_NAME
LOG_FILE = DATA_DIR / "daniav.log"
QUARANTINE_DIR = DATA_DIR / "Quarantine"
LOCK_NAME = "DaniAV_V1_SingleInstance"

DATA_DIR.mkdir(parents=True, exist_ok=True)
QUARANTINE_DIR.mkdir(parents=True, exist_ok=True)

try:
    import psutil
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "psutil", "-q"])
    import psutil

try:
    from pypresence import Presence, InvalidPipe
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pypresence", "-q"])
    from pypresence import Presence, InvalidPipe


@dataclass
class ScanStats:
    started_at: datetime.datetime
    elapsed: float = 0.0
    processes_checked: int = 0
    files_checked: int = 0
    startup_entries_checked: int = 0
    connections_checked: int = 0
    alerts: list = field(default_factory=list)

    @property
    def alert_count(self):
        return len(self.alerts)


@dataclass
class Alert:
    kind: str
    title: str
    detail: str
    path: str = ""
    pid: Optional[int] = None
    port: Optional[int] = None
    severity: str = "medium"
    action: str = "review"

    def display(self):
        suffix = f" | {self.detail}" if self.detail else ""
        return f"{self.title}{suffix}"


logging.basicConfig(
    filename=str(LOG_FILE),
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(APP_NAME)

BANNER = r"""
██████╗  █████╗ ███╗   ██╗██╗ █████╗ ██╗   ██╗
██╔══██╗██╔══██╗████╗  ██║██║██╔══██╗██║   ██║
██║  ██║███████║██╔██╗ ██║██║███████║██║   ██║
██║  ██║██╔══██║██║╚██╗██║██║██╔══██║╚██╗ ██╔╝
██████╔╝██║  ██║██║ ╚████║██║██║  ██║ ╚████╔╝
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝╚═╝  ╚═══╝
"""

KNOWN_BAD_PROCESSES = {
    "xmrig.exe",
    "lolminer.exe",
    "mimikatz.exe",
    "njrat.exe",
    "asyncrat.exe",
    "remcos.exe",
    "quasarrat.exe",
    "nanocore.exe",
    "darkcomet.exe",
    "orcus.exe",
}

HIGH_RISK_EXTENSIONS = {
    ".vbs",
    ".vbe",
    ".wsf",
    ".wsh",
    ".jse",
    ".hta",
    ".scr",
    ".pif",
}

SUSPICIOUS_PORTS = {
    1337,
    4444,
    4445,
    5555,
    7777,
    8888,
    9001,
    31337,
    12345,
}

SCAN_DIRECTORIES = [
    USER_HOME / "Downloads",
    USER_HOME / "AppData" / "Local" / "Temp",
    USER_HOME / "AppData" / "Roaming",
]

rpc = None
rpc_enabled = False
rpc_started = int(time.time())
rpc_last_update = 0.0
rpc_last_connect_attempt = 0.0
single_instance_handle = None


def get_env_int(name, default, minimum, maximum):
    value = os.getenv(name, "").strip()
    if not value:
        return default
    try:
        parsed = int(value)
    except ValueError:
        return default
    return max(minimum, min(parsed, maximum))


SCAN_DELAY = get_env_int(
    "DANIAV_SCAN_DELAY",
    DEFAULT_SCAN_DELAY,
    15,
    3600,
)

RPC_INTERVAL = get_env_int(
    "DANIAV_RPC_INTERVAL",
    DEFAULT_RPC_INTERVAL,
    15,
    3600,
)

DISCORD_CLIENT_ID = os.getenv("DANIAV_DISCORD_CLIENT_ID", "").strip()
GITHUB_URL = os.getenv("DANIAV_GITHUB_URL", "https://github.com/ubcz/daniav").strip()


def acquire_single_instance():
    global single_instance_handle

    kernel32 = ctypes.windll.kernel32
    kernel32.SetLastError(0)
    handle = kernel32.CreateMutexW(None, False, LOCK_NAME)

    if not handle:
        return False

    if kernel32.GetLastError() == 183:
        kernel32.CloseHandle(handle)
        return False

    single_instance_handle = handle
    return True


def release_single_instance():
    global single_instance_handle

    if single_instance_handle:
        try:
            ctypes.windll.kernel32.ReleaseMutex(single_instance_handle)
            ctypes.windll.kernel32.CloseHandle(single_instance_handle)
        except Exception:
            pass
        single_instance_handle = None


def clear_screen():
    os.system("cls")


def header(rpc_state="OFFLINE"):
    clear_screen()
    print(BANNER)
    print(f"  {APP_NAME}  |  V{VERSION}")
    print("  Lightweight Windows security monitor")
    print(f"  Discord Rich Presence: {rpc_state}")
    print(f"  Scan interval: {SCAN_DELAY}s")
    print("=" * 76)


def sha256_file(path: Path):
    try:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except (OSError, PermissionError):
        return None


def rpc_configured():
    return DISCORD_CLIENT_ID.isdigit() and 5 <= len(DISCORD_CLIENT_ID) <= 20


def rpc_connect(force=False):
    global rpc, rpc_enabled, rpc_last_connect_attempt

    now = time.monotonic()

    if not force and now - rpc_last_connect_attempt < 30:
        return False

    rpc_last_connect_attempt = now

    if not rpc_configured():
        rpc_enabled = False
        rpc = None
        return False

    try:
        rpc = Presence(DISCORD_CLIENT_ID)
        rpc.connect()
        rpc_enabled = True
        log.info("Discord Rich Presence connected")
        return True
    except Exception as exc:
        rpc = None
        rpc_enabled = False
        log.warning("Discord Rich Presence unavailable: %s", exc)
        return False


def rpc_close():
    global rpc, rpc_enabled

    if rpc is not None:
        try:
            rpc.close()
        except Exception:
            pass

    rpc = None
    rpc_enabled = False


def rpc_update(details, state, alert_count=0, force=False):
    global rpc_last_update

    if not rpc_enabled or rpc is None:
        if not rpc_connect():
            return False

    now = time.monotonic()

    if not force and now - rpc_last_update < RPC_INTERVAL:
        return False

    rpc_last_update = now
    status_text = "System clean" if alert_count == 0 else f"{alert_count} alert(s)"

    try:
        rpc.update(
            details=details[:128],
            state=state[:128],
            start=rpc_started,
            large_text=f"{APP_NAME} V{VERSION}",
            small_text=status_text[:128],
            buttons=[
                {"label": "DaniAV on GitHub", "url": GITHUB_URL}
            ],
        )
        return True
    except InvalidPipe:
        log.warning("Discord IPC disconnected")
        rpc_close()
        if rpc_connect(force=True):
            return rpc_update(details, state, alert_count, force=True)
        return False
    except Exception as exc:
        log.warning("Discord activity update failed: %s", exc)
        return False


def register_startup():
    run_key = r"Software\Microsoft\Windows\CurrentVersion\Run"
    executable = Path(sys.executable).resolve()
    script = Path(__file__).resolve()
    command = f'"{executable}" "{script}" --watch --no-startup'

    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            run_key,
            0,
            winreg.KEY_SET_VALUE,
        ) as key:
            winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, command)

        log.info("Startup entry registered")
        return True
    except OSError as exc:
        log.warning("Startup registration failed: %s", exc)
        return False


def remove_startup():
    run_key = r"Software\Microsoft\Windows\CurrentVersion\Run"

    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            run_key,
            0,
            winreg.KEY_SET_VALUE,
        ) as key:
            winreg.DeleteValue(key, APP_NAME)

        log.info("Startup entry removed")
        return True
    except FileNotFoundError:
        return True
    except OSError as exc:
        log.warning("Startup removal failed: %s", exc)
        return False


def get_startup_entries():
    result = []
    run_key = r"Software\Microsoft\Windows\CurrentVersion\Run"

    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, run_key) as key:
            index = 0
            while True:
                try:
                    name, value, _ = winreg.EnumValue(key, index)
                    result.append((name, value))
                    index += 1
                except OSError:
                    break
    except OSError:
        pass

    return result


def scan_processes(stats):
    for process in psutil.process_iter(["pid", "name"]):
        try:
            stats.processes_checked += 1
            name = (process.info.get("name") or "").lower()

            if name in KNOWN_BAD_PROCESSES:
                alert = Alert(
                    kind="process",
                    title="Known suspicious process",
                    detail=f"{process.info.get('name')} | PID {process.info.get('pid')}",
                    pid=process.info.get("pid"),
                    severity="high",
                    action="review",
                )
                stats.alerts.append(alert)
                log.warning(alert.display())

        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue


def scan_files(stats):
    visited = set()

    for directory in SCAN_DIRECTORIES:
        if not directory.exists() or not directory.is_dir():
            continue

        try:
            for item in directory.rglob("*"):
                try:
                    if not item.is_file():
                        continue

                    stat = item.stat()
                    identity = (stat.st_dev, stat.st_ino)

                    if identity in visited:
                        continue

                    visited.add(identity)
                    stats.files_checked += 1

                    if item.suffix.lower() not in HIGH_RISK_EXTENSIONS:
                        continue

                    digest = sha256_file(item)

                    alert = Alert(
                        kind="file",
                        title="High-risk script detected",
                        detail=f"{item.suffix.lower()} | {item}",
                        path=str(item),
                        severity="medium",
                        action="review",
                    )

                    stats.alerts.append(alert)
                    log.warning(
                        "File indicator: %s | SHA256=%s",
                        item,
                        digest or "unavailable",
                    )

                except (OSError, PermissionError):
                    continue

        except (OSError, PermissionError):
            continue


def scan_startup(stats):
    temp_paths = [
        str(Path(os.environ.get("TEMP", ""))).lower(),
        str(USER_HOME / "AppData" / "Local" / "Temp").lower(),
        str(USER_HOME / "AppData" / "Roaming").lower(),
    ]

    own_name = APP_NAME.lower()

    for name, value in get_startup_entries():
        stats.startup_entries_checked += 1
        normalized = str(value).lower()

        if name.lower() == own_name:
            continue

        if any(fragment and fragment in normalized for fragment in temp_paths):
            alert = Alert(
                kind="startup",
                title="Suspicious startup entry",
                detail=f"{name} | {value}",
                severity="high",
                action="review",
            )
            stats.alerts.append(alert)
            log.warning(alert.display())


def scan_network(stats):
    try:
        connections = psutil.net_connections(kind="inet")
    except psutil.AccessDenied:
        log.warning("Network scan visibility is limited without elevation")
        return

    for connection in connections:
        stats.connections_checked += 1

        local_port = connection.laddr.port if connection.laddr else None
        remote_port = connection.raddr.port if connection.raddr else None
        matched = sorted({
            port for port in (local_port, remote_port)
            if port in SUSPICIOUS_PORTS
        })

        if not matched:
            continue

        remote = (
            f"{connection.raddr.ip}:{connection.raddr.port}"
            if connection.raddr else "N/A"
        )

        alert = Alert(
            kind="network",
            title="Suspicious network port",
            detail=f"ports {matched} | remote {remote} | PID {connection.pid or 'unknown'}",
            port=matched[0],
            severity="medium",
            action="review",
        )
        stats.alerts.append(alert)
        log.warning(alert.display())


def run_scan():
    stats = ScanStats(started_at=datetime.datetime.now())

    scan_processes(stats)
    scan_files(stats)
    scan_startup(stats)
    scan_network(stats)

    stats.elapsed = (datetime.datetime.now() - stats.started_at).total_seconds()
    return stats


def print_stats(stats):
    print()
    print("=" * 76)
    print("  Scan complete")
    print(f"  Processes checked:       {stats.processes_checked}")
    print(f"  Files checked:           {stats.files_checked}")
    print(f"  Startup entries checked: {stats.startup_entries_checked}")
    print(f"  Connections checked:     {stats.connections_checked}")
    print(f"  Alerts:                  {stats.alert_count}")
    print(f"  Duration:                {stats.elapsed:.2f}s")
    print("=" * 76)

    if not stats.alerts:
        print("  STATUS: CLEAN")
        print("  No configured indicators were detected.")
        return

    print("  STATUS: REVIEW NEEDED")
    print()

    for index, alert in enumerate(stats.alerts[:20], 1):
        print(f"  {index:02d}. {alert.display()}")

    if len(stats.alerts) > 20:
        print(f"  ... and {len(stats.alerts) - 20} more")


def open_path(path: Path):
    try:
        os.startfile(str(path))
    except OSError as exc:
        print(f"  Could not open path: {exc}")


def quarantine_file(path_text):
    path = Path(path_text)

    if not path.exists() or not path.is_file():
        return False, "File no longer exists"

    try:
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        destination = QUARANTINE_DIR / f"{path.stem}_{stamp}{path.suffix}"
        shutil.move(str(path), str(destination))

        log.warning("User quarantined file: %s -> %s", path, destination)
        return True, str(destination)
    except (OSError, PermissionError) as exc:
        return False, str(exc)


def defender_scan():
    candidates = [
        Path(os.environ.get("ProgramFiles", "")) / "Windows Defender" / "MpCmdRun.exe",
        Path(os.environ.get("ProgramW6432", "")) / "Windows Defender" / "MpCmdRun.exe",
    ]

    defender = next((path for path in candidates if path.exists()), None)

    if defender is None:
        return False, "Windows Defender command line tool was not found"

    command = [
        str(defender),
        "-Scan",
        "-ScanType",
        "1",
    ]

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=1800,
        )
        output = (result.stdout or result.stderr or "").strip()
        return result.returncode == 0, output[-4000:]
    except subprocess.TimeoutExpired:
        return False, "Windows Defender scan timed out"
    except OSError as exc:
        return False, str(exc)


def rpc_test():
    if not rpc_configured():
        return False

    if not rpc_connect(force=True):
        return False

    return rpc_update(
        "DaniAV is online",
        "Discord Rich Presence test",
        0,
        force=True,
    )


def explain_discord():
    print()
    print("  Discord setup")
    print("  1. Create a Discord application")
    print("  2. Copy its Application ID")
    print("  3. Set DANIAV_DISCORD_CLIENT_ID to that ID")
    print("  4. Keep the Discord desktop client running")
    print("  5. Start DaniAV again")
    print()
    print("  Optional repository button:")
    print("  Set DANIAV_GITHUB_URL to your GitHub repository URL")


def run_once():
    header("CONNECTING" if rpc_configured() else "NOT CONFIGURED")
    rpc_connect(force=True)

    rpc_update(
        "Scanning your PC",
        "Running security checks",
        0,
        force=True,
    )

    stats = run_scan()
    print_stats(stats)

    rpc_update(
        "System clean" if not stats.alerts else f"{len(stats.alerts)} alert(s)",
        "Scan complete",
        len(stats.alerts),
        force=True,
    )

    return stats


def run_watch(register):
    if register:
        startup_ok = register_startup()
    else:
        startup_ok = True

    rpc_connect(force=True)

    cycle = 0

    while True:
        cycle += 1
        rpc_state = "READY" if rpc_enabled else "OFFLINE"
        header(rpc_state)

        if cycle == 1:
            print(f"  Startup protection: {'ENABLED' if startup_ok else 'UNAVAILABLE'}")
            if not rpc_enabled:
                print("  Discord: set DANIAV_DISCORD_CLIENT_ID to enable activity")

        rpc_update(
            "DaniAV is protecting your PC",
            f"Security cycle {cycle}",
            0,
            force=True,
        )

        stats = run_scan()
        print_stats(stats)

        rpc_update(
            "System clean" if not stats.alerts else f"{len(stats.alerts)} alert(s)",
            f"Cycle {cycle} complete",
            len(stats.alerts),
            force=True,
        )

        print()
        print(f"  Next scan in {SCAN_DELAY} seconds")
        print("  Ctrl+C stops DaniAV")
        time.sleep(SCAN_DELAY)


def interactive_menu():
    while True:
        header("READY" if rpc_enabled else "OFFLINE")
        print("  1  Scan now")
        print("  2  Start continuous protection")
        print("  3  Test Discord Rich Presence")
        print("  4  Run Windows Defender quick scan")
        print("  5  Open log file")
        print("  6  Open quarantine folder")
        print("  7  Enable startup")
        print("  8  Disable startup")
        print("  9  Discord setup help")
        print("  0  Exit")
        print()

        choice = input("  DaniAV > ").strip()

        if choice == "1":
            run_once()
            input("\n  Press ENTER to continue")
        elif choice == "2":
            run_watch(register=False)
        elif choice == "3":
            header("TESTING")
            print("  Discord test:", "OK" if rpc_test() else "FAILED")
            input("\n  Press ENTER to continue")
        elif choice == "4":
            header("DEFENDER")
            print("  Starting Windows Defender quick scan...")
            ok, message = defender_scan()
            print(f"  Result: {'SUCCESS' if ok else 'FAILED'}")
            if message:
                print()
                print(message)
            input("\n  Press ENTER to continue")
        elif choice == "5":
            open_path(LOG_FILE)
        elif choice == "6":
            open_path(QUARANTINE_DIR)
        elif choice == "7":
            print("  Startup:", "ENABLED" if register_startup() else "FAILED")
            input("\n  Press ENTER to continue")
        elif choice == "8":
            print("  Startup:", "DISABLED" if remove_startup() else "FAILED")
            input("\n  Press ENTER to continue")
        elif choice == "9":
            explain_discord()
            input("\n  Press ENTER to continue")
        elif choice == "0":
            return
        else:
            print("  Unknown option")
            time.sleep(1)


def parse_args():
    parser = argparse.ArgumentParser(
        prog=APP_NAME,
        description="Lightweight Windows security monitoring tool",
    )
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--no-rpc", action="store_true")
    parser.add_argument("--no-startup", action="store_true")
    parser.add_argument("--version", action="version", version=f"{APP_NAME} {VERSION}")
    return parser.parse_args()


def main():
    global DISCORD_CLIENT_ID, rpc_enabled

    if os.name != "nt":
        print("DaniAV V1 requires Windows.")
        return 1

    if not acquire_single_instance():
        print("DaniAV is already running.")
        return 1

    try:
        args = parse_args()

        if args.no_rpc:
            DISCORD_CLIENT_ID = ""
            rpc_enabled = False

        if args.once:
            run_once()
            return 0

        if args.watch:
            run_watch(register=not args.no_startup)
            return 0

        interactive_menu()
        return 0

    except KeyboardInterrupt:
        print()
        print("  DaniAV stopped safely")
        log.info("DaniAV stopped by user")
        return 0
    except Exception as exc:
        log.error("Unhandled application error: %s", exc)
        log.error(traceback.format_exc())
        print()
        print(f"  Fatal error: {exc}")
        return 1
    finally:
        rpc_close()
        release_single_instance()


if __name__ == "__main__":
    raise SystemExit(main())
